// Theme




const body = document.querySelector("body");
const theme = document.querySelector("#theme");
theme.addEventListener("change", ChangeTheme)
function ChangeTheme(element){
  const selectValue = element.target.value;
  switch(selectValue){
    case "white":
      body.style.backgroundColor = "white"
      body.style.color = "black";
    break;
    default:
      body.style.backgroundColor = "black";
      body.style.color = "white";
  }

}















const btnVid = document.querySelector(".BtnVid");
const boxDiv = document.querySelector(".hidden");
const video = document.querySelector("video");

 btnVid.addEventListener("click", () => boxDiv.classList.remove("hidden"));

video.addEventListener("click", (event) => {
    event.stopPropagation();
    if(video.paused){
      video.play();
    }else{
     video.pause();
   };
});

 boxDiv.addEventListener("click", () => boxDiv.classList.add("hidden"));

video.addEventListener("mouseenter", () => {
  hoverTimer = setTimeout(() => {
    video.style.opacity = "1"; // Убираем затемнение
    video.classList.add("no-hover-effect"); // Добавляем класс, чтобы убрать hover эффект
  }, 300); // Запуск через 1 секунду
});

// Обработчик для выхода с видео
video.addEventListener("mouseleave", () => {
  clearTimeout(hoverTimer); // Сброс таймера
  video.style.opacity = ""; // Возвращаем стиль по умолчанию
  video.classList.remove("no-hover-effect"); // Убираем класс
});